# InstructLab Governance

For information about how the InstructLab project governance operates, see [InstructLab Governance](https://github.com/instructlab/community/blob/main/GOVERNANCE.md).
